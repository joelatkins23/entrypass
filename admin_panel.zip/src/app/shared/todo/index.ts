export class Todo {
    constructor(public text: string, public type: string, public isChecked: boolean) {}
}
